APP_TITLE = "Trogon"
PACKAGE_NAME = "trogon"
TEXTUAL_URL = "https://github.com/textualize/textual"
ORGANIZATION_NAME = "T"
